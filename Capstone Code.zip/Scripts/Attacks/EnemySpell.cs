﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpell : MonoBehaviour
{
    public GameObject Player;
    private float lifetime;

    // Start is called before the first frame update
    void Start()
    {
        Player = GameObject.FindGameObjectWithTag("Player");
        lifetime = 5.0f;
    }

    // Update is called once per frame
    void Update()
    {
        lifetime -= Time.deltaTime;
        if (Player != null)
        {
            Vector3 targetPosition = new Vector3(Player.transform.position.x, Player.transform.position.y, Player.transform.position.z);
            this.transform.LookAt(targetPosition);
            transform.Translate(Vector3.forward * 10.0f * Time.deltaTime);
        }

        //after 5 seconds destroy spell
        if(lifetime == 0)
        {
            Destroy(gameObject);
        }
       
    }

    void OnCollisionEnter(Collision other)
    {
        if(other.gameObject.tag == "Player")
        {
            Debug.Log("HIT Player");
            Destroy(this.gameObject);
            Player.GetComponent<PlayerHealth>().Health -= 5;
        }
    }
}
