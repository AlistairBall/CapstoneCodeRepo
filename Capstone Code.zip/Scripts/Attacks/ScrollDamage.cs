﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScrollDamage : MonoBehaviour
{
   
    public GameObject DamageText;
    public LayerMask m_LayerMask;

    private float tickTime;

    // Start is called before the first frame update
    void Start()
    {
        //destroy spell after 10 seconds
        Invoke("finishSpell", 10);
    }

    // Update is called once per frame
    void Update()
    {
        Damage();
    }

    void finishSpell()
    {
        Destroy(gameObject);
    }

    void Damage()
    {
        //checks what enemies are in damage zone at any given time
        GameObject instance;
       Collider[] Enemies = Physics.OverlapBox(transform.position, transform.localScale * 8, Quaternion.identity, m_LayerMask);
        int i = 0;
        while( i < Enemies.Length)
        {
            tickTime -= Time.deltaTime;

            if (tickTime <= 0)
            {
                foreach (Collider hit in Enemies)
                 {
                    //Enemy take damaage
                    Enemies[i].GetComponent<EnemyHealth>().health -= 20;

                    instance = Instantiate(DamageText, transform.position, Quaternion.identity);
                    instance.transform.GetComponent<CombatText>().mainTarget = Enemies[i].gameObject;
                    instance.transform.GetComponent<CombatText>().damage = 20; 
                 }
                tickTime = 2.0f;
            }
            i++;
        }
    }
}
