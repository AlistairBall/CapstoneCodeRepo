﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectEnemy : MonoBehaviour
{

    public GameObject SelectedEnemy;
    public GameObject[] allEnemies;
    public GameObject PreviousEnemy;

    private int index = 0;

    // Update is called once per frame
    void Update()
    {
        //Update what enemies are in the scene at any given time
        allEnemies = GameObject.FindGameObjectsWithTag("Enemy");

        if (Input.GetKeyDown(KeyCode.Tab) && SelectedEnemy == null)
        {
            //Find closest enemy and highlight them
            FindClosestEnemy();
            SelectedEnemy.transform.GetComponent<ShaderSelected>().Selected();
            //store closest enemy as previous enemy for selection loop
            PreviousEnemy = SelectedEnemy;

        }
        else if (Input.GetKeyDown(KeyCode.Tab) && SelectedEnemy != null)
        {

            //Highlight first enemy in array and deselect previous enemy
            if (index == 0 && PreviousEnemy != null)
            {
                SelectedEnemy = allEnemies[index];
                SelectedEnemy.transform.GetComponent<ShaderSelected>().Selected();
                PreviousEnemy.transform.GetComponent<ShaderSelected>().Deselected();
                index++;
            }

            // if theres only one enemy deselect enemy on TAB
            else if (allEnemies.Length == 1)
            {
                SelectedEnemy.transform.GetComponent<ShaderSelected>().Deselected();
                SelectedEnemy = null;
            }

            //if on last enemy
            else if (index >= allEnemies.Length - 1)
            {
                SelectedEnemy = allEnemies[index];
                PreviousEnemy = allEnemies[index - 1];
                SelectedEnemy.transform.GetComponent<ShaderSelected>().Selected();
                PreviousEnemy.transform.GetComponent<ShaderSelected>().Deselected();
                index = 0;
                PreviousEnemy = allEnemies[allEnemies.Length - 1];

            }

            else
            {
                SelectedEnemy = allEnemies[index];
                PreviousEnemy = allEnemies[index - 1];
                SelectedEnemy.transform.GetComponent<ShaderSelected>().Selected();
                PreviousEnemy.transform.GetComponent<ShaderSelected>().Deselected();
                index++;
            }
        }

        //deselect enemy with right click
        if (Input.GetKeyDown(KeyCode.Mouse1) && SelectedEnemy != null)
        {
            //deselect enemy
            SelectedEnemy.transform.GetComponent<ShaderSelected>().Deselected();
            SelectedEnemy = null;
        }
    }

    //find closest enemy as first selection
    void FindClosestEnemy()
    {
        float distanceToClosestEnemy = Mathf.Infinity;
        allEnemies = GameObject.FindGameObjectsWithTag("Enemy");
        foreach (GameObject currentEnemy in allEnemies)
        {
            float distanceToEnemy = (currentEnemy.transform.position - transform.position).sqrMagnitude;
            if (distanceToEnemy < distanceToClosestEnemy)
            {
                distanceToClosestEnemy = distanceToEnemy;

                SelectedEnemy = currentEnemy;
            }
        }
    }
}
