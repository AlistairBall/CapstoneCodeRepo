﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShaderSelected : MonoBehaviour
{

    public Shader shader1;
    public Shader shader2;
    public Renderer rend;
  
    // Start is called before the first frame update
    void Start()
    {
        rend = GetComponent<Renderer>();
        shader1 = Shader.Find("Legacy Shaders/Diffuse");
        shader2 = Shader.Find("Legacy Shaders/Self-Illumin/Diffuse");
    }

    //functions that switch shader to illumin
    public void Selected()
    {
        rend.material.shader = shader2;
    }
    public void Deselected()
    {
        rend.material.shader = shader1;
    }
}
