﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpellAttack : MonoBehaviour
{
    public GameObject target;

    // Update is called once per frame
    void Update()
    {
        //target is passed in from EnemySelection script
     if(target != null)
        {
            Vector3 targetPosition = new Vector3(target.transform.position.x, target.transform.position.y, target.transform.position.z);
            this.transform.LookAt(targetPosition);
            transform.Translate(Vector3.forward * 10.0f * Time.deltaTime);
        }   
    }

    void OnCollisionEnter(Collision other)
    {
        if(other.gameObject.tag == "Enemy")
        {
            Destroy(this.gameObject);
        }
    }
}
