﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponDamage : MonoBehaviourPunCallbacks, IPunObservable
{
    public int damage;	
    
    #region IPunObservable implementation
	public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
		if (stream.IsWriting)
		{
			stream.SendNext(damage);
		}
		else
		{
			this.damage = (int)stream.ReceiveNext();
		}

	}
	#endregion
}
