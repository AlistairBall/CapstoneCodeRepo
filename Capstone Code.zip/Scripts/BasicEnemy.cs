﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasicEnemy : MonoBehaviour
{
    public Transform Enemy;
    public Transform PlayerPos;

    public GameObject player;
    public GameObject Spawner;
    public GameObject DamageText;
    Animator Anim;

    public Shader shader1;
    public Shader shader2;
    public Renderer rend;

    private bool HitOnce = false;
    private bool once = false;
    private bool attack = false;
    private float distance;
    private float speed;
    private int health;
    int rotationSpeed = 80;

    void Start()
    {
        Enemy = transform;
        player = GameObject.FindGameObjectWithTag("Player");
        PlayerPos = player.transform;
        Anim = GetComponent<Animator>();
        InvokeRepeating("ResetDamage", 1.0f, 1.2f);
        InvokeRepeating("DamagePlayer", 0.0f, 2.0f);
        health = GetComponent<EnemyHealth>().health;

    }

    // Update is called once per frame
    void Update()
    {
        //set reference health to local health
        GetComponent<EnemyHealth>().health = health;

        //enemy faces player and cannot rotate on x axis
        Vector3 direction = PlayerPos.position - this.transform.position;
        distance = Vector3.Distance(transform.position, player.transform.position);
        float angle = Vector3.Angle(direction, Enemy.up);

        //If not attacking, chase player
        if (!attack && !once)
        {
            speed = 0.06f;
            this.transform.Translate(0, 0, Time.deltaTime * speed);
            this.transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), rotationSpeed * Time.deltaTime);
            transform.position = Vector3.MoveTowards(transform.position, player.transform.position, 0.07f);
            Anim.SetInteger("Condition", 1);
            Anim.SetBool("Damaged", false);
        }

        if (attack)
        {
            speed = 0.0f;
            DamagePlayer();
        }

        //Death logic
        if (health <= 0)
        {
            if (!once)
            {
                once = true;
                Anim.SetBool("Damaged", false);
                Anim.SetInteger("Condition", 9);
                Destroy(gameObject, 2);
                speed = 0;
                //drop spawner after death animation plays out
                Invoke("DropSpawner", 2.0f);
            }
        }

        if (HitOnce && !once)
        {
            Anim.SetBool("Damaged", true);
        }

        LookAtTarget();
    }

    void LookAtTarget()
    {
        //always face direction of player
        Vector3 dir = PlayerPos.position - transform.position;
        Quaternion lookRotation = Quaternion.LookRotation(dir);
        Vector3 rotation = Quaternion.Lerp(transform.rotation, lookRotation, Time.deltaTime * rotationSpeed).eulerAngles;
        transform.rotation = Quaternion.Euler(0f, rotation.y, 0f);
    }

    void OnCollisionEnter(Collision other)
    {
        GameObject instance;
        if (health > 0)
        {
            if (other.gameObject.tag == "Equipped" && HitOnce == false)
            {
                HitOnce = true;
                int Damage = other.gameObject.GetComponent<WeaponDamage>().damage;
                health -= Damage;

                //UI Text
                instance = Instantiate(DamageText, transform.position, Quaternion.identity);
                instance.transform.GetComponent<CombatText>().mainTarget = gameObject;
                instance.transform.GetComponent<CombatText>().damage = Damage;
            }

            if (other.gameObject.tag == "Spell")
            {
                int Damage = other.gameObject.GetComponent<WeaponDamage>().damage;

                health -= Damage;

                instance = Instantiate(DamageText, transform.position, Quaternion.identity);
                instance.transform.GetComponent<CombatText>().mainTarget = gameObject;
                instance.transform.GetComponent<CombatText>().damage = Damage;

                Destroy(other.gameObject);
            }
        }
    }

    void DropSpawner()
    {
        Instantiate(Spawner, transform.position, Quaternion.identity);
        Spawner.SetActive(true);
    }

    void OnTriggerEnter(Collider other)
    {
        if (health > 0)
        {
            //If player is within range, begin attack state
            if (other.gameObject.tag == "Player")
            {
                attack = true;
                Anim.SetInteger("Condition", 4);
                
            }
        }
    }
    void OnTriggerExit(Collider other)
    {
        //If player is out of range exit attack state
        if (other.gameObject.tag == "Player")
        {
            attack = false;
        }


    }

    void ResetDamage()
    {
        HitOnce = false;
    }

    void DamagePlayer()
    {
        //When in range deal damage otherwise play animation
        if (attack && distance <= 2 && !once)
        {
            Anim.Play("Attack", -1, 0f);
            player.GetComponent<PlayerHealth>().Health -= 3;
        }

        else if (attack)
        {
            Anim.Play("Attack", -1, 0f);
        }
    }


}
