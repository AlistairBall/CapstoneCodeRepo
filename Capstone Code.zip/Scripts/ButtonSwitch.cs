﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Networking;
using UnityEngine.UI;

public class ButtonSwitch : NetworkBehaviour
{
	public RoomPlacerScript roomplacerScript;


	public void Start()
	{
		
	}

	public void Update()
	{
		roomplacerScript = GameObject.FindGameObjectWithTag("Player").GetComponentInChildren<RoomPlacerScript>();
	}


	[Command]
	public void CmdGreenRoom()
	{
		//find the player gameobject
		//access the roomtype int from the Roomplacescript & change it

		roomplacerScript.RoomType = 1;
		Debug.Log("DM room selected");
	}

	[Command]
	public void CmdPurpleRoom()
	{
		roomplacerScript.RoomType = 2;
		Debug.Log("Combat room selected");
	}


}