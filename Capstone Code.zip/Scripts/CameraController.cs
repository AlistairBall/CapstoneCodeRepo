﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{

	//private PhotonView PV;


    private const float Y_ANGLE_MIN = 0.0f;
    private const float Y_ANGLE_MAX = 50.0f;

    public Transform player, target;
    public Transform CamTransform;
    Quaternion rotation;

    private float distance = 1.3f;
    private float currentX = 0.0f;
    private float currentY = 0.0f;
    private float sensitivityX = 3.0f;
    private float sensitivityY = 2.0f;
    float tempX;
    float tempY;

  
    // Start is called before the first frame update
    void Start()
    {   
        CamTransform = transform;
        CamTransform.rotation = transform.rotation;
    }

    void Update()
    { 
        //update player rotation to equal camera rotation
			currentX += Input.GetAxis("Mouse X") * sensitivityX;
			currentY += Input.GetAxis("Mouse Y") * sensitivityY;
			currentY = Mathf.Clamp(currentY, Y_ANGLE_MIN, Y_ANGLE_MAX);
    }

    // Update is called once per frame
    void LateUpdate()
    { 
			Vector3 dir = new Vector3(0, 0, -distance);

			//Save where camera is when shift is hit
			if (Input.GetKeyDown(KeyCode.LeftShift))
			{
				tempX = currentX;
				tempY = currentY;
			}
			//Return Camera to the position when shift was pressed
			else if (Input.GetKeyUp(KeyCode.LeftShift))
			{
				currentX = tempX;
				currentY = tempY;
				Time.timeScale = 1;
			}

            //slows time on shift
			if (Input.GetKey(KeyCode.LeftShift))
			{
				rotation = Quaternion.Euler(0, currentX, 0);
				Time.timeScale = 0.2f;
			}
            //return to original camera position
			else
			{
				rotation = Quaternion.Euler(currentY, currentX, 0);
				player.rotation = Quaternion.Euler(0, currentX, 0);
			}

			CamTransform.position = target.position + rotation * dir;
			CamTransform.LookAt(target.position);
		}
	}
   

