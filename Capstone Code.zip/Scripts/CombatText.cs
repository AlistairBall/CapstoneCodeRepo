﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CombatText : MonoBehaviour
{
    public GameObject mainTarget;
    public GameObject camera1;
    public GUIStyle textStyle = new GUIStyle();
    public Vector2 targetPos;

    public int damage;
    public float fadeTime;
    public float yPos;
    public float newAlpha;
    public float randomX;
    public float randomY;
    public float fadeOutTimer;
   

    // Start is called before the first frame update
    void Start()
    {
        targetPos = Camera.main.WorldToScreenPoint(mainTarget.transform.position);
        camera1 = GameObject.FindGameObjectWithTag("Player1Camera");
    }

    void OnGUI()
    {
        //Setting the UI text's position
        if(mainTarget != null)
        {
            GUI.Label(new Rect(targetPos.x - 50, Screen.height - targetPos.y - 140 - yPos, 120, 30), "" + damage, textStyle);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (mainTarget != null)
        {
            targetPos = Camera.main.WorldToScreenPoint(mainTarget.transform.position);
        }
        //fade out damage text
        if(fadeTime > 0)
        {
            if(fadeOutTimer > 0)
            {
                fadeOutTimer -= Time.deltaTime;
            }
            else
            {
                newAlpha -= 0.05f;
                textStyle.normal.textColor = new Vector4(1, 1, 1, newAlpha);
            }
            //text will rise up
            fadeTime -= Time.deltaTime;
            yPos += 1.0f;
            if(textStyle.fontSize < 20)
            {
                textStyle.fontSize += 1;
            }
        }
        else
        {
            Destroy(gameObject);
        }
    }
}
