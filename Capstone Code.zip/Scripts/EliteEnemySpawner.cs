﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EliteEnemySpawner : MonoBehaviour
{

	public GameObject[] Spawner;
	public GameObject EliteEnemy;

	//public GameObject Door;

	private PhotonView PV;
	private bool spawn = false;


	// Start is called before the first frame update
	void Start()
	{
		PV = GetComponent<PhotonView>();
	}

	// Update is called once per frame
	void Update()
	{
		Spawner = GameObject.FindGameObjectsWithTag("EliteSpawn");
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "EnemySpawnTrigger")
		{
			other.gameObject.SetActive(false);
			Debug.Log("PLAYER ENTERED ROOM");
			spawn = true;
			print(spawn);
			// Door.SetActive(true);
			PV.RPC("RPC_Spawn", RpcTarget.Others);


		}
	}

	[PunRPC]
	void RPC_Spawn()
	{
		if (spawn)
		{
			for (int i = 0; i < Spawner.Length; i++)
			{
				if (Spawner[i].gameObject.tag == "EliteSpawn")
				{
					PhotonNetwork.Instantiate("EliteEnemy", Spawner[i].transform.position, Quaternion.identity);
				}

			}

		}
	}
}

