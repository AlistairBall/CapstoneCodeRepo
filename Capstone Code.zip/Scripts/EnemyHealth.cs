﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviourPunCallbacks, IPunObservable
{
    public int health;


	#region IPunObservable implementation
	public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
		if(stream.IsWriting)
		{
			stream.SendNext(health);
		}
		else
		{
			this.health = (int)stream.ReceiveNext();
		}
		
	}
	#endregion
}
