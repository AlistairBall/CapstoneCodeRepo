﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawn : MonoBehaviour
{

	public GameObject[] Spawner;
    public GameObject[] doors;
    public GameObject basicChest;
    public GameObject redChest;
    public GameObject blueChest;
	public GameObject BasicEnemy;
	public GameObject MageEnemy;
	public GameObject EliteEnemy;

	public BoxCollider bc;
	private PhotonView PV;

	private bool spawn = false;
    public int enemyCount;
    private int rarity;


	// Start is called before the first frame update
	void Start()
	{
		PV = GetComponent<PhotonView>();
		bc = this.GetComponent<BoxCollider>();
	}

	// Update is called once per frame
	void Update()
	{
        //check if any enemy has died and if so decrement the enemy count
        if (BasicEnemy.GetComponent<EnemyHealth>().health <= 0 || MageEnemy.GetComponent<EnemyHealth>().health <= 0 || EliteEnemy.GetComponent<EnemyHealth>().health <= 0)
        {
            enemyCount--;
        }
        //if all enemies are dead remove doors so player can continue
        if (enemyCount == 0)
        {
            for (int i = 0; i < doors.Length; i++)
            {
                doors[i].SetActive(false);
            }

            foreach (GameObject spawner in Spawner)
            {
                //33% chance to spawn a chest of varying rarity depending on the spawner type
                rarity = Random.Range(1, 3);
                if (spawner.gameObject.tag == "BasicSpawn" && rarity == 2)
                {
                    PhotonNetwork.InstantiateSceneObject("basicChest", spawner.transform.position, Quaternion.identity);
                }

                if (spawner.gameObject.tag == "EliteSpawn" && rarity == 2)
                {
                    PhotonNetwork.InstantiateSceneObject("redChest", spawner.transform.position, Quaternion.identity);
                }

                if (spawner.gameObject.tag == "MageSpawn" && rarity == 2)
                {
                    PhotonNetwork.InstantiateSceneObject("blueChest", spawner.transform.position, Quaternion.identity);
                }
            }
          
        }
	}

	private void OnTriggerEnter(Collider other)
	{
        //when player enters the room
		if (other.gameObject.tag == "Player")
		{
			bc.enabled = false;
            spawn = true;
			this.PV.RPC("RPC_Spawn", RpcTarget.All, null);
		}
	}

	[PunRPC]
	void RPC_Spawn()
	{
		if (spawn)
		{
            //spawn in the appropriate enemy depending on spawner
            //number of enemies spawned matches number of spawners
			for (int i = 0; i < Spawner.Length; i++)
			{
				if (Spawner[i].gameObject.tag == "BasicSpawn")
				{
					PhotonNetwork.InstantiateSceneObject("BasicEnemy", Spawner[i].transform.position, Quaternion.identity);
                    enemyCount++;
				}

				if (Spawner[i].gameObject.tag == "EliteSpawn")
				{
					PhotonNetwork.InstantiateSceneObject("EliteEnemy", Spawner[i].transform.position, Quaternion.identity);
                    enemyCount++;
				}

				if (Spawner[i].gameObject.tag == "MageSpawn")
				{
					PhotonNetwork.InstantiateSceneObject("MageEnemy", Spawner[i].transform.position, Quaternion.identity);
                    enemyCount++;
				}

			}
            //close doors until fight is over
            for (int i = 0; i < doors.Length; i++)
            {
                doors[i].SetActive(true);
            }

		}
	}


}