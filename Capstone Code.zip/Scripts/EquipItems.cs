﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EquipItems : MonoBehaviour
{
    public GameObject currentItem;
    public GameObject hand;
    public GameObject lightningScroll;
    public GameObject fireScroll;
    public GameObject LargeHealth;
    public GameObject player;
    public GameObject candle;

    public Text tips;
   
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        hand = GameObject.FindGameObjectWithTag("LeftHand");
        candle = GameObject.FindGameObjectWithTag("Candle");
        
        
    }

    // Update is called once per frame
    void Update()
    {
      
    }

    public void Equip()
    {
        GameObject instance;

       // tips.GetComponent<FadeText>().fading = true;
       // tips.text = "Press E to use item or Q to drop";

        // instantiate instance of object without colliders in left hand
        if (gameObject.tag == "LightningScroll")
        {

            if (candle.activeSelf)
            {
                candle.SetActive(false);
                instance = Instantiate(lightningScroll, player.transform.position, Quaternion.identity);
                instance.GetComponent<PickupScript>().enabled = false;
                currentItem = instance;

                currentItem.transform.parent = hand.transform;
                currentItem.transform.localPosition = new Vector3(-3.7f, -3.9f, 5.5f);
                currentItem.transform.localRotation = Quaternion.Euler(-65.7f, 137.8f, 37.9f);
                Destroy(gameObject);
                player.GetComponent<UseItem>().currentItem = currentItem;
            }  
        }

      else if (gameObject.tag == "FireScroll")
        {
            // instantiate instance of object without colliders in left hand
            if (candle.activeSelf)
            {
                candle.SetActive(false);
                    instance = Instantiate(fireScroll, player.transform.position, Quaternion.identity);
                    instance.GetComponent<PickupScript>().enabled = false;
                    currentItem = instance;

                    currentItem.transform.parent = hand.transform;
                    currentItem.transform.localPosition = new Vector3(-3.7f, -3.9f, 5.5f);
                    currentItem.transform.localRotation = Quaternion.Euler(-65.7f, 137.8f, 37.9f);
                    Destroy(gameObject);
                    player.GetComponent<UseItem>().currentItem = currentItem;    
            }
        }

        else if (gameObject.tag == "LargePotion")
        {
            //instantiate instance of object without colliders in left hand
            if (candle.activeSelf)
            {
                candle.SetActive(false);
            
                instance = Instantiate(LargeHealth, player.transform.position, Quaternion.identity);
                instance.GetComponent<PickupScript>().enabled = false;
                instance.GetComponent<BoxCollider>().enabled = false;

                currentItem = instance;
                currentItem.transform.parent = hand.transform;
                currentItem.transform.localPosition = new Vector3(-2.3f, -19.8f, -40.8f);
                currentItem.transform.localRotation = Quaternion.Euler(-65.7f, 137.8f, 37.9f);
                Destroy(gameObject);
                player.GetComponent<UseItem>().currentItem = currentItem;
            }
        }
    }
}
