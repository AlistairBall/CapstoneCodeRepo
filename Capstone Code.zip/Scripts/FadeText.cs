﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class FadeText : MonoBehaviour
{

    public Text tips;
    public bool fading;
    // Start is called before the first frame update
    void Start()
    {
        tips = GetComponent<Text>();
        fading = false;
    }
    //fades text based on boolean over 1 second
    void Update()
    {
        if (fading == true)
        {
            tips.CrossFadeAlpha(1, 1.0f, false);
        }
        if(fading == false)
        {
            tips.CrossFadeAlpha(0, 1.0f, false);
        }
    } 
}
