﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{

    public Image Healthbar;
    public Text healthText;
    public GameObject player;

    public int Min;
    public int Max;
    public int currentValue;
    public float currentPercentage;

    public void Health(int health)
    {
        if(health != currentValue)
        {
            //avoid dividing by 0
            if(Max - Min == 0)
            {
                currentValue = 0;
                currentPercentage = 0;
            }
            //Update health and percentage
            else
            {
                currentValue = health;
                currentPercentage = (float)currentValue / (float)(Max - Min);
            }
            //update health bar and text
            healthText.text = string.Format("{0} %", Mathf.RoundToInt(currentPercentage * 100));
            Healthbar.fillAmount = currentPercentage;
        }
    }
  
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
    }

    //Pass on UI health to player health
    void Update()
    {
        int health = player.GetComponent<PlayerHealth>().Health;
        Health(health);
    } 
}
