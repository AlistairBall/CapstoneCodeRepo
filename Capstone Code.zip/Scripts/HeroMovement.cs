﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


//All Character ANIMATIONS credited to MIXAMO.COM

public class HeroMovement : MonoBehaviour
{

	//Networking Stuff
	private PhotonView PV;

	private Vector3 moveDirection;  
	public Transform cameraComponent;
    public Transform SpawnSpell;
    
    public GameObject InHand;
    public GameObject SelectedEnemy;
    public GameObject[] allEnemies;
    public GameObject LightSpellPrefab;
    public GameObject FireSpellPrefab;
    public GameObject PoisonSpellPrefab;
    public GameObject PreviousEnemy;
    public GameObject EquippedStaff;

	public GameObject endGameButton;
	public GameObject endGameText;
	public GameObject winGameText;
  

    Equip WeaponType;
    public bool hitOnce = false;
	public bool isDead = false;
    public Text tips;
    Animator Anim;

    public int noOfClicks = 0;
    private int combo = 0;
    private int index = 0;
    private float speed = 6.0f;
    private float lastClickedTime = 0;
    //Delay between clicks for which clicks will be considered as combo
    private float maxComboDelay = 2;
    AnimatorStateInfo _stateInfo;

    
 



    void Start()
	{
		
		endGameButton = GameObject.FindGameObjectWithTag("HeroEndGameButton");
		endGameText = GameObject.FindGameObjectWithTag("HeroEndGameText");
		winGameText = GameObject.FindGameObjectWithTag("WinGameText");

		PV = GetComponent<PhotonView>();
        Anim = GetComponent<Animator>();
        _stateInfo = Anim.GetCurrentAnimatorStateInfo(0);
        WeaponType = GameObject.FindGameObjectWithTag("Player").GetComponent<Equip>();
        InvokeRepeating("ResetDamage", 1.0f, 1.2f);
        noOfClicks = 0;
        tips.GetComponent<FadeText>().fading = true;
        tips.text = "Welcome to the Dungeon, Equip any item you see with SPACE";
        Invoke("FadeOut", 4);

		endGameButton.SetActive(false);
		endGameText.SetActive(false);
		winGameText.SetActive(false);

    }

	// Update is called once per frame
	void Update()
	{

        if (PV.IsMine && isDead == false)
        {
            //updates forward direction for movement
            Vector3 cameraComponentF = cameraComponent.forward;
            Vector3 cameraComponentR = cameraComponent.right;

            cameraComponentF.y = 0;
            cameraComponentR.y = 0;
            cameraComponentF = cameraComponentF.normalized;
            cameraComponentR = cameraComponentR.normalized;

            //Player movement
            if (Input.GetKey(KeyCode.W))
            {
                Anim.SetInteger("Condition", 1);
                transform.position += (cameraComponentF * Input.GetAxis("Vertical") * speed) * Time.deltaTime;
            }
            if (Input.GetKey(KeyCode.S))
            {
                Anim.SetInteger("Condition", 3);
                transform.position += (cameraComponentF * Input.GetAxis("Vertical") * speed) * Time.deltaTime;
            }
            //Move Left or Right
            if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D))
            {
                transform.position += (cameraComponentR * Input.GetAxis("Horizontal") * speed) * Time.deltaTime;
                Anim.SetInteger("Condition", 6);
            }

            //reset combo
            if (Time.time - lastClickedTime > maxComboDelay)
            {
                noOfClicks = 0;
            }

            //Start of melee attack mechanics and combos.
            if (WeaponType.meleeEquipped == true)
            {


              
                if (Input.GetMouseButtonDown(0))
                {
                    //Record time of last button click
                    lastClickedTime = Time.time;
                    noOfClicks++;

                    if (noOfClicks == 1)
                    {
                        Anim.SetBool("Combo1", true);
                    }
                    else if(noOfClicks == 0)
                    {

                    }
                    //limit/clamp number of clicks between 0 and 3 because the combo has 3 animations
                    noOfClicks = Mathf.Clamp(noOfClicks, 0, 3);

                }

                //Change animation states based on number of clickes during each combo piece
                if (Anim.GetCurrentAnimatorStateInfo(0).IsName("Combo1") && noOfClicks == 1)
                {
                    Anim.SetBool("Combo1", false);
					noOfClicks = 0;
                }
                else if (Anim.GetCurrentAnimatorStateInfo(0).IsName("Combo1") && noOfClicks > 1)
                {
                    Anim.SetBool("Combo1", false);
                    Anim.SetBool("Combo2", true);
                }
                else if (Anim.GetCurrentAnimatorStateInfo(0).IsName("Combo2") && noOfClicks == 2)
                {
                    Anim.SetBool("Idle", true);
                    Anim.SetBool("Combo2", false);
                }
                else if (Anim.GetCurrentAnimatorStateInfo(0).IsName("Combo2") && noOfClicks == 3)
                {
                    Anim.SetBool("Combo3", true);
                    Anim.SetBool("Combo2", false);
                }
                if (Anim.GetCurrentAnimatorStateInfo(0).IsName("Combo3"))
                {
                    Anim.SetBool("Idle", true);
                    Anim.SetBool("Combo3", false);
                    Anim.SetBool("Combo2", false);
                    Anim.SetBool("Combo1", false);
                    noOfClicks = 0;
                }
            }

            //Start of magic Staff mechanics
            else if (WeaponType.meleeEquipped == false)
            {
                Debug.Log("Melee false");
                //retrieve selected enemy data from SelectEnemy script
                SelectedEnemy = GetComponent<SelectEnemy>().SelectedEnemy;
                EquippedStaff = GameObject.FindGameObjectWithTag("HeroStaff");
                if (Input.GetKeyDown(KeyCode.Mouse0) && SelectedEnemy == null)
                {
                    //UI for No enemy selected
                    tips.GetComponent<FadeText>().fading = true;
                    tips.text = "No target selected, use TAB to select target";
                    Invoke("FadeOut", 2);

                }
                if (Input.GetKeyDown(KeyCode.Mouse0) && SelectedEnemy != null)
                {
                              
                    Anim.SetBool("Spell", true);
                    Invoke("RangedSpell", 0.7f);
                }
            }

            //if In any other animation state do not idle
            if (Anim.GetInteger("Condition") > 0)
            {
                Anim.SetBool("Idle", false);
                Anim.SetBool("Spell", false);
            }

            //return to idle if no key is pressed.
            if (!Input.anyKey)
            {
                Anim.SetBool("Idle", true);
                Anim.SetBool("Spell", false);
                Anim.SetInteger("Condition", 0);
                
            }
        }  


		if(GetComponent<PlayerHealth>().Health <= 0)
		{
			Anim.SetInteger("Condition", 20);
			endGameButton.SetActive(true);
			endGameText.SetActive(true);
			isDead = true;

		}



    }

    void FadeOut()
    {
        tips.GetComponent<FadeText>().fading = false;
    }

    //take damage from enemy swings (when enemy is being posessed)
    void OnCollisionEnter(Collision other)
    {
         if(other.gameObject.tag == "EnemyWeapon" && hitOnce == false)
         {
            GetComponent<PlayerHealth>().Health -= 15;
            hitOnce = true;
            Debug.Log("Here");
         }
     }


	private void OnTriggerEnter(Collider other)
	{
		if(other.gameObject.tag == "HeroWin")
		{
			endGameButton.SetActive(true);
			winGameText.SetActive(true);
			isDead = true;
		}

		if(other.gameObject.tag == "Break")
		{
			PhotonNetwork.Destroy(other.gameObject);
		}
	}

	//reset bool to allow damage to be taken again
	void ResetDamage()
    {
        hitOnce = false;
    }

    //Old function where selection was based on mouse click screen coordinates
    void SelectedTarget()
    {
        
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;
        Debug.DrawRay(ray.origin, ray.direction * 10, Color.yellow);
        int layer = LayerMask.GetMask("Enemy");

        if (Physics.Raycast(ray, out hit, 100.0f, layer))
        {
            if(hit.transform.tag == "Enemy")
            {
               
                SelectedEnemy = hit.transform.gameObject;
            }
        }
       
    }

    //spawn speel prefabs depending on staff equipped
    void RangedSpell()
    {
        GameObject Instance;

        //each spell passes on selected enemy from SelectedEnemy script as the target for the spell
        if (EquippedStaff.layer == 12)
        {
            SpawnSpell = EquippedStaff.transform.GetChild(0);
            Instance = PhotonNetwork.InstantiateSceneObject("LightSpell", SpawnSpell.transform.position, Quaternion.identity);
            Instance.transform.GetComponent<SpellAttack>().target = SelectedEnemy;
        }
        else if(EquippedStaff.layer == 13)
        {
            SpawnSpell = EquippedStaff.transform.GetChild(0);
            Instance = PhotonNetwork.InstantiateSceneObject("StaffFireSpell", SpawnSpell.transform.position, Quaternion.identity);
            Instance.transform.GetComponent<SpellAttack>().target = SelectedEnemy;
        }
        else
        {
            SpawnSpell = EquippedStaff.transform.GetChild(0);
            Instance = PhotonNetwork.InstantiateSceneObject("PoisonSpell", SpawnSpell.transform.position, Quaternion.identity);
            Instance.transform.GetComponent<SpellAttack>().target = SelectedEnemy;
        }
        
    }


	public void backToLobby(int sceneNumber)
	{
		SceneManager.LoadScene(0);
	}




}
