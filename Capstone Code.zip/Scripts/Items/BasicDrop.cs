﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasicDrop : MonoBehaviour
{
    // Var
    public Transform SpawnBase;

    public GameObject largePotion;
    public GameObject EnemyAxe;
    public GameObject OldAxe;

    private int swordRarity;
    private int ItemType;
    public string SpawnOption;
    public bool spawn;

    // Use this for initialization
    void Start()
    {
        spawn = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (SpawnOption == "Random" && !spawn) { RandomSpawn(); spawn = true; }
    }

    void RandomSpawn()
    {
        Random.seed = System.DateTime.Now.Millisecond;
        ItemType = Random.Range(1, 4);
        swordRarity = Random.Range(1, 4);
        
        
        //50% chance to drop health
        if (ItemType <= 2)
        {
            Instantiate(largePotion, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);  
        }

        //25% chance to drop weapon
        else if (ItemType == 3)
        {
            //25% chnace to drop enemyAxe
            if (swordRarity == 1)
            {
                Instantiate(EnemyAxe, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y + 1, SpawnBase.transform.position.z), Quaternion.identity);
            }
            //75% chance to drop old axe
            else
            {
                Instantiate(OldAxe, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y + 1, SpawnBase.transform.position.z), Quaternion.identity);
            }
        }
        //25% chance to drop nothing
        else
        {

        } 
    }
}
