﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasicEnemyDrop : MonoBehaviour
{
    // Var
    public Transform SpawnBase;
    public GameObject[] ScrollPrefab;
    public GameObject smallPotion;
    public GameObject largePotion;
    public GameObject BasicSword;
    public GameObject Axe;

    private int swordRarity;
    private int scrollRarity;
    private int ItemType;
    public string SpawnOption;
    public bool spawn;

    // Use this for initialization
    void Start()
    {
        spawn = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (SpawnOption == "Random" && !spawn) { RandomSpawn(); spawn = true; }
    }

    void RandomSpawn()
    {

        Random.seed = System.DateTime.Now.Millisecond;
        ItemType = Random.Range(1, 6);
        swordRarity = Random.Range(1, 4);
        scrollRarity = Random.Range(0, ScrollPrefab.Length);

        //50% chance to drop health
        if (ItemType <= 3)
        {
          Instantiate(largePotion, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity); 
        }

        //16% chance to drop weapon
        else if (ItemType == 5)
        {
            //25% chance to drop axe
            if (swordRarity == 1)
            {
                Instantiate(Axe, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
            }
            //75% chance to drop basic sword
            else
            {
                Instantiate(BasicSword, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
            }
        }
        //16% chance to drop scroll
        else if (ItemType == 6)
        {
            Instantiate(ScrollPrefab[scrollRarity], new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
        }
    }
}
