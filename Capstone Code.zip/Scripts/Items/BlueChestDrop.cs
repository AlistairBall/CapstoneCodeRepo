﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueChestDrop : MonoBehaviour
{
    // Var
    public Transform SpawnBase;

    public GameObject[] ScrollPrefab;
    public GameObject largePotion;
    public GameObject LightStaff;
    public GameObject FireStaff;

    private int Staffrarity;
    private int ScrollRarity;
    private int ItemType;

    public string SpawnOption;
    public bool spawn;

    // Use this for initialization
    void Start()
    {
        spawn = false;
    }

    // Update is called once per frame
    void Update()
    {
        //string was set for testing when previous builds allowed for customizable outcomes
        //calls to spawn
        if (SpawnOption == "Random" && !spawn) { RandomSpawn(); spawn = true; }
    }
    void RandomSpawn()
    {
        //Sets up Random integers to handle rarity of drops
        Random.seed = System.DateTime.Now.Millisecond;
        ItemType = Random.Range(1, 10);
        Staffrarity = Random.Range(1, 10);
        ScrollRarity = Random.Range(0, ScrollPrefab.Length - 1);

        //30% chance to drop health
        if (ItemType <= 2)
        {
            Instantiate(largePotion, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);

        }
        //30% chance to drop staff
        else if (ItemType >= 4 && ItemType <= 6)
        {
            if (Staffrarity <= 7)
            {
                Instantiate(FireStaff, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
            }
            else 
            {
                Instantiate(LightStaff, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
            }
        }
        //40% chance to drop random scroll
        else if (ItemType >= 7 && ItemType <= 10)
        {
            Instantiate(ScrollPrefab[ScrollRarity], new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
        }
    }

}
