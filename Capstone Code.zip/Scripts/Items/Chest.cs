﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Chest : MonoBehaviour
{

    public GameObject Spawner;
    Animator Anim;
    public Text tips;
    private bool opened = false;
   
    // Start is called before the first frame update
    void Start()
    {
        Anim = GetComponent<Animator>();
    }

    void OnTriggerStay(Collider other)
    {

        tips.GetComponent<FadeText>().fading = true;
        tips.text = "Press Space to open chest";

        //Begin chest opening animation
        if (Input.GetKeyDown(KeyCode.Space) && opened == false)
        {
            opened = true;
            Anim.SetBool("Open", true);
            Invoke("SpawnItem", 0.7f);
        }
    }

    void OnTriggerExit(Collider other)
    {
        tips.GetComponent<FadeText>().fading = false;
    }

    void SpawnItem()
    {
       //Chest item spawn
        Instantiate(Spawner, transform.position, Quaternion.identity);  
    }
}
