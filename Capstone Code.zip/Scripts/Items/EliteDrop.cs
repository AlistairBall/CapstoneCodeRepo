﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EliteDrop : MonoBehaviour
{
    // Var
    public Transform SpawnBase;
    public GameObject largePotion;
    public GameObject EnemyAxe;
    public GameObject RuneHammer;
    public GameObject RoundSword;




    private int swordRarity;
    private int ItemType;
    public string SpawnOption;
    public bool spawn;

    // Use this for initialization
    void Start()
    {
        spawn = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (SpawnOption == "Random" && !spawn) { RandomSpawn(); spawn = true; }
    }

    void RandomSpawn()
    {
        Random.seed = System.DateTime.Now.Millisecond;
        ItemType = Random.Range(1, 7);
        swordRarity = Random.Range(1, 10);

        //42% chance to drop health
        if (ItemType <= 3)
        {
            Instantiate(largePotion, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
        }

        //58% chance to drop weapon
        else if (ItemType >= 4 && ItemType <= 7)
        {
            //30% chance to drop RuneHammer
            if (swordRarity <= 3)
            {
                Instantiate(RuneHammer, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y + 1, SpawnBase.transform.position.z), Quaternion.identity);
            }
            //30% chance to drop enemyAxe
            else if (swordRarity >= 4 && swordRarity <= 6)
            {
                Instantiate(EnemyAxe, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y + 1, SpawnBase.transform.position.z), Quaternion.identity);
            }
            //40% chance to drop round sword
            else if (swordRarity >= 7 && swordRarity <= 10)
            {
                Instantiate(RoundSword, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y + 1, SpawnBase.transform.position.z), Quaternion.identity);
            }
        }
    }
}
