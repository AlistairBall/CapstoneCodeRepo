﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Equip : MonoBehaviour
{

    public GameObject hand;
    public GameObject currentWeapon;
    public Text tips;
    Animator Anim;

    public bool meleeEquipped = true;
    public bool LightStaffEquipped = false;
    public bool FireStaffEquipped = false;

    public Queue<GameObject> WeaponQueue = new Queue<GameObject>();

    // Start is called before the first frame update
    void Start()
    {
        WeaponQueue.Enqueue(GameObject.FindGameObjectWithTag("Equipped"));
        currentWeapon = GameObject.FindGameObjectWithTag("Equipped");
        Anim = GetComponent<Animator>();
    }


    void OnTriggerStay(Collider other)
    {
        //when near other weapons show text UI
        if (other.gameObject.tag == "Weapon" || other.gameObject.tag == "Staff" || other.gameObject.tag == "LightStaff" || other.gameObject.tag == "PoisonStaff"){
           // tips.GetComponent<FadeText>().fading = true;
            //tips.text = "Press Space to Equip";
        }

        //When swapping to a melee weapon
        if (other.gameObject.tag == "Weapon" && Input.GetKeyDown(KeyCode.Space))
        {
            
            Debug.Log(other);
            meleeEquipped = true;
            LightStaffEquipped = false;
            FireStaffEquipped = false;
            WeaponQueue.Enqueue(other.gameObject);

            //if holding melee weapon
            if (currentWeapon.gameObject.tag == "Equipped")
            {
                currentWeapon.gameObject.tag = "Weapon";
            }
            //switch equipped weapon to default layer
            currentWeapon.gameObject.layer = 0;

            //switch ground weapon to player layer (ignores collision with player)
            //switched ground weapon to be tagged equipped
            other.gameObject.layer = 10;
            other.gameObject.tag = "Equipped";

            //detatches equipped weapon from hand and to the other weapons position
            currentWeapon.transform.parent = null;
            currentWeapon.transform.position = other.transform.position;
            currentWeapon.transform.rotation = Quaternion.identity;

            //ground weapon becomes child of players right hand and is positioned accordingly
            other.transform.parent = hand.transform;
            other.transform.localPosition = new Vector3(1.8f, 1.1f, -5.2f);
            other.transform.localRotation = Quaternion.identity;
            other.transform.localRotation = Quaternion.Euler(174.0f, -94.9f, 71.4f);

            //take the original equipped weapon out of queue and assign new equipped weapon as the first in queue
            WeaponQueue.Dequeue();
            currentWeapon = WeaponQueue.Peek();
        }

        else if (other.gameObject.tag == "Staff" && Input.GetKeyDown(KeyCode.Space))
        {
            meleeEquipped = false;
            LightStaffEquipped = false;
            FireStaffEquipped = true;
            WeaponQueue.Enqueue(other.gameObject);

            //detatch current weapon from player
            currentWeapon.transform.parent = null;
            currentWeapon.transform.position = other.transform.position;
            currentWeapon.transform.rotation = Quaternion.identity;

           // tips.GetComponent<FadeText>().fading = true;
           // tips.text = "Press TAB to select target";

            //if switching from melee to staff
            if (currentWeapon.gameObject.tag == "Equipped")
            {
                currentWeapon.gameObject.tag = "Weapon";
                currentWeapon.gameObject.layer = 0;
            }


            //position staff accordingly
            other.transform.parent = hand.transform;
            other.transform.localPosition = new Vector3(-13.0f, 15.6f, 14.9f);
            other.transform.localRotation = Quaternion.identity;
            other.transform.localRotation = Quaternion.Euler(8.2f, -98.2f, 122.4f);

            //take the original equipped weapon out of queue and assign new equipped weapon as the first in queue
            WeaponQueue.Dequeue();
            currentWeapon = WeaponQueue.Peek();
        }


        else if (other.gameObject.tag == "LightStaff" && Input.GetKeyDown(KeyCode.Space))
        {
            meleeEquipped = false;
            LightStaffEquipped = true;
            FireStaffEquipped = false;
            WeaponQueue.Enqueue(other.gameObject);

            currentWeapon.transform.parent = null;
            currentWeapon.transform.position = other.transform.position;
            currentWeapon.transform.rotation = Quaternion.identity;
            //tips.text = "Press TAB to select target";

            if (currentWeapon.gameObject.tag == "Equipped")
            {
                currentWeapon.gameObject.tag = "Weapon";
                currentWeapon.gameObject.layer = 0;
            }

            other.transform.parent = hand.transform;
            other.transform.localPosition = new Vector3(-10.0f, 31f, 43.0f);
            other.transform.localRotation = Quaternion.identity;
            other.transform.localRotation = Quaternion.Euler(8.2f, -98.2f, 122.4f);

            WeaponQueue.Dequeue();
            currentWeapon = WeaponQueue.Peek();

        }

        else if (other.gameObject.tag == "PoisonStaff" && Input.GetKeyDown(KeyCode.Space))
        {
            meleeEquipped = false;
            LightStaffEquipped = false;
            FireStaffEquipped = false;
            WeaponQueue.Enqueue(other.gameObject);

            currentWeapon.transform.parent = null;
            currentWeapon.transform.position = other.transform.position;
            currentWeapon.transform.rotation = Quaternion.identity;
           // tips.text = "Press TAB to select target";

            if (currentWeapon.gameObject.tag == "Equipped")
            {
                currentWeapon.gameObject.tag = "Weapon";
                currentWeapon.gameObject.layer = 0;
            }

            other.transform.parent = hand.transform;
            other.transform.localPosition = new Vector3(3.0f, -10f, -21.0f);
            other.transform.localRotation = Quaternion.identity;
            other.transform.localRotation = Quaternion.Euler(23.3f, -279.8f, 230.2f);

            WeaponQueue.Dequeue();
            currentWeapon = WeaponQueue.Peek();

        }
    }

    void OnTriggerExit(Collider other)
    {
        //tips.GetComponent<FadeText>().fading = false;
    }
}
