﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MageDrop : MonoBehaviour
{
    // Var
    public Transform SpawnBase;

    public GameObject[] ScrollPrefab;
    public GameObject LargePotion;
    public GameObject EnemyStaff;

    private int ScrollRarity;
    private int ItemType;
    public string SpawnOption;
    public bool spawn;

    // Use this for initialization
    void Start()
    {
        spawn = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (SpawnOption == "Random" && !spawn) { RandomSpawn(); spawn = true; }
    }

    void RandomSpawn()
    {
        Random.seed = System.DateTime.Now.Millisecond;
        ItemType = Random.Range(1, 7);
        ScrollRarity = Random.Range(0, ScrollPrefab.Length);

        //28% chance to drop health
        if (ItemType <= 2)
        {
            Instantiate(LargePotion, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
        }
        //14% chance to drop staff
        else if (ItemType == 4)
        {
            Instantiate(EnemyStaff, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y + 1, SpawnBase.transform.position.z), Quaternion.identity);
        }
        //28% chance to drop scroll
        else if (ItemType >= 6 && ItemType <= 7)
        {
            Instantiate(ScrollPrefab[ScrollRarity], new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
        }
        //30% chance to drop nothing
    }
}
