﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RedChestDrop : MonoBehaviour
{
    // Var
    public Transform SpawnBase;
   
    public GameObject largePotion;
    public GameObject RuneAxe;
    public GameObject OrnateAxe;
    public GameObject Runesword;
    public GameObject OrnateSword;
    public GameObject RoundSword;

    private int swordRarity;
    private int scrollRarity;
    private int ItemType;
    public string SpawnOption;
    public bool spawn;

    // Use this for initialization
    void Start()
    {
        spawn = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (SpawnOption == "Random" && !spawn) { RandomSpawn(); spawn = true; }
    }

    void RandomSpawn()
    {
        Random.seed = System.DateTime.Now.Millisecond;
        ItemType = Random.Range(1, 6);
        swordRarity = Random.Range(0, 30);

        // 33% chance to drop health
        if (ItemType <= 2)
        {
            Instantiate(largePotion, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);

        }

        //66% chance to drop weapon
        else if (ItemType >= 3 && ItemType <= 6)
        {
            //26% chance to drop round sword
            if (swordRarity <= 7)
            {
                Instantiate(RoundSword, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
            }
            //20% chance to drop run axe
            else if (swordRarity >= 8 && swordRarity <= 13)
            {
                Instantiate(RuneAxe, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
            }
            //20% chance to drop ornateAxe
            else if (swordRarity >= 14 && swordRarity <= 19)
            {
                Instantiate(OrnateAxe, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
            }
            //20% chance to drop ornate sword
            else if (swordRarity >= 20 && swordRarity <= 25)
            {
                Instantiate(OrnateSword, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
            }
            //16% chance to drop runeSword
            else if (swordRarity >= 26 && swordRarity <= 30)
            {
                Instantiate(Runesword, new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
            }
        }
    }
}
