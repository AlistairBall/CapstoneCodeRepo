﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScryingOrb : MonoBehaviour
{
    // Start is called before the first frame update

    public GameObject[] cameras;
    public GameObject playerCamera;

    private int currentCameraIndex;
    private int randomInt;
    public bool Posessing = false;
    void Start()
    {
        currentCameraIndex = 0;
        cameras = GameObject.FindGameObjectsWithTag("RoomCam");
        playerCamera = GameObject.FindGameObjectWithTag("Player2Camera");

        //Turn all cameras off and disable select enemy script
        for (int i = 0; i < cameras.Length; i++)
        {
            cameras[i].GetComponent<Camera>().enabled = false;
            cameras[i].GetComponent<SelectEnemy>().enabled = false;
        }   
    }

    void OnTriggerStay(Collider other)
    {
        //Update camera array
        cameras = GameObject.FindGameObjectsWithTag("RoomCam");

        //when inside trigger hit Space to activate scrying orb
        if (Input.GetKeyDown(KeyCode.Space) && Posessing == false)
        {
            playerCamera.gameObject.SetActive(false);
            
            if (currentCameraIndex < cameras.Length)
            {
                //if not on first camera in array
                if (currentCameraIndex != 0)
                {
                    cameras[currentCameraIndex - 1].GetComponent<Camera>().enabled = false;
                    cameras[currentCameraIndex - 1].GetComponent<SelectEnemy>().enabled = false;
                }
                else
                {
                    cameras[currentCameraIndex].GetComponent<Camera>().enabled = true;
                    cameras[currentCameraIndex].GetComponent<SelectEnemy>().enabled = true;
                }
                currentCameraIndex++;
            }
            //on last camera
            else
            {
                cameras[currentCameraIndex - 1].GetComponent<Camera>().enabled = false;
                cameras[currentCameraIndex - 1].GetComponent<SelectEnemy>().enabled = false;
                currentCameraIndex = 0;
                cameras[currentCameraIndex].GetComponent<Camera>().enabled = true;
                cameras[currentCameraIndex].GetComponent<SelectEnemy>().enabled = true;
                currentCameraIndex++;
            }
        }

        //If you are not in the main game camera
        //Press Q to switch back to the main game camera
        if (Input.GetKeyDown(KeyCode.Q))
        {
            Posessing = false;
            if (currentCameraIndex != 0)
            {
                cameras[currentCameraIndex - 1].GetComponent<Camera>().enabled = false;
                cameras[currentCameraIndex - 1].GetComponent<SelectEnemy>().enabled = false;
                playerCamera.gameObject.SetActive(true);
               
            }
            else
            {
                cameras[currentCameraIndex].GetComponent<Camera>().enabled = false;
                cameras[currentCameraIndex].GetComponent<SelectEnemy>().enabled = false;
                playerCamera.gameObject.SetActive(true);
            }
        }
    }
}
