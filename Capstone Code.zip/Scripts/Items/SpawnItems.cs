﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnItems : MonoBehaviour
{
    // Var
    public Transform SpawnBase;
    public GameObject[] HealthPrefab;
    public GameObject[] SwordPrefab;
    public GameObject[] StaffPrefab;
    public GameObject[] itemPrefab;

    private int swordRarity;
    private int staffRarity;
    private int healthRarity;
    private int itemRarity;
    private int ItemType;
    public string SpawnOption;
    public bool spawn;

    // Use this for initialization
    void Start()
    {
        spawn = false;
    }

    // Update is called once per frame
    //checks what string is given and responds with functions to spawn specific items
    void Update()
    {
        if (SpawnOption == "Random" && !spawn) { RandomSpawn(); spawn = true; }
        else if (SpawnOption == "Health" && !spawn) { SpawnHealth(); spawn = true; }

        else if (SpawnOption == "Sword" && !spawn) { SpawnSword(); spawn = true; }
        else if (SpawnOption == "Staff" && !spawn) { SpawnStaff(); spawn = true; }
    }

    void RandomSpawn()
    {
        //integers of various rarities
        Random.seed = System.DateTime.Now.Millisecond;
        ItemType = Random.Range(1, 6);
        swordRarity = Random.Range(0, SwordPrefab.Length);
        staffRarity = Random.Range(0, StaffPrefab.Length);
        healthRarity = Random.Range(0, HealthPrefab.Length);
        itemRarity = Random.Range(0, itemPrefab.Length);

        //33% chance to drop health
        if (ItemType == 1 || ItemType == 2)
        {
            Instantiate(HealthPrefab[healthRarity], new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z ), Quaternion.identity);
        }
        //16% chance to drop sword
        else if (ItemType == 3)
        {
            Instantiate(SwordPrefab[swordRarity], new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
        }
        //16% chance to drop staff
        else if (ItemType == 4)
        {
            Instantiate(StaffPrefab[staffRarity], new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
        }
        //33% chance to drop scroll
        else if (ItemType == 5 || ItemType == 6)
        {
            Instantiate(itemPrefab[itemRarity], new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
        }
    }

    //functions based on string
    void SpawnHealth()
    {
        Instantiate(HealthPrefab[0], new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
    }
    void SpawnSword()
    {
        Instantiate(SwordPrefab[1], new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
    }
    void SpawnStaff()
    {
        Instantiate(StaffPrefab[0], new Vector3(SpawnBase.transform.position.x, SpawnBase.transform.position.y, SpawnBase.transform.position.z), Quaternion.identity);
    }



}
