﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CameraSwitcher : MonoBehaviour
{
	// Start is called before the first frame update
	public GameObject MapCamera;
	public GameObject PlayerCamera;
    public Text tips;
	//private PhotonView PV;

	private int CameraSwitcherInt = 2;
	private bool usingMap = false;
	private bool isLocked = false;

	
	public GameObject shopRoomButton;
	public GameObject basicRoomButton;
	public GameObject combatRoomButton;
	public GameObject combatRoom02Button;
	public GameObject trapRoom01Button;
	public GameObject trapRoom02Button;
	

	void Start()
    {
		//PV = GetComponent<PhotonView>();
    }

    // Update is called once per frame
    void Update()
    {
       
		if(PlayerCamera == null)
		{
			PlayerCamera = GameObject.FindGameObjectWithTag("Player2Camera");
		}

		if (shopRoomButton == null & basicRoomButton == null & combatRoomButton == null & combatRoom02Button == null & trapRoom01Button == null & trapRoom02Button == null)
		{
			shopRoomButton = GameObject.FindGameObjectWithTag("ShopRoomButton");
			basicRoomButton = GameObject.FindGameObjectWithTag("BasicRoomButton");
			combatRoomButton = GameObject.FindGameObjectWithTag("CombatRoomButton");
			combatRoom02Button = GameObject.FindGameObjectWithTag("CombatRoom2Button");
			trapRoom01Button = GameObject.FindGameObjectWithTag("TrapRoom01Button");
			trapRoom02Button = GameObject.FindGameObjectWithTag("TrapRoom02Button");

		}


		//switch it to player camera
		if (Input.GetKeyDown(KeyCode.Q))
		{
			CameraSwitcherInt = 2;
			isLocked = false;
			//TODO:
			//Make the cursor dissapear when on player 
		}


		if (CameraSwitcherInt == 2)
		{

			MapCamera.SetActive(false);
			shopRoomButton.SetActive(false);
			basicRoomButton.SetActive(false);
			combatRoomButton.SetActive(false);
			combatRoom02Button.SetActive(false);
			trapRoom01Button.SetActive(false);
			trapRoom02Button.SetActive(false);
			PlayerCamera.SetActive(true);
			Debug.Log("Map Camera turned off");
		}

		else if(CameraSwitcherInt == 1)
		{
			MapCamera.SetActive(true);
			shopRoomButton.SetActive(true);
			basicRoomButton.SetActive(true);
			combatRoomButton.SetActive(true);
			combatRoom02Button.SetActive(true);
			trapRoom01Button.SetActive(true);
			trapRoom02Button.SetActive(true);
			PlayerCamera.SetActive(false);
			Debug.Log("Map Camera turned on");

		}

    }


	private void OnTriggerStay(Collider other)
	{
		if (other.gameObject.tag == "Player2")
		{   
            //switch it to Map maker camera
            if (Input.GetKeyDown(KeyCode.R) && isLocked == false)
			 {
				isLocked = true;
				CameraSwitcherInt = 1;
                tips.GetComponent<FadeText>().fading = false;
            }
		}

	}

    void OnTriggerEnter(Collider other)
    {
        tips = GameObject.FindGameObjectWithTag("Tips2").GetComponent<Text>();
        tips.GetComponent<FadeText>().fading = true;
        tips.text = "Press R to enter map, Press Q to exit";
		//MapCamera = GameObject.FindGameObjectWithTag("MainCamera").GetComponentInChildren<Camera>();
    }

    void OnTriggerExit(Collider other)
    {
        tips.GetComponent<FadeText>().fading = false;
    }

   
}
