﻿using UnityEngine;
using System.Collections;
using UnityEngine.Networking;

public class ChooseHero : NetworkManager
{
	[SerializeField] Vector3 playerSpawnPos;
	[SerializeField] GameObject character1;
	[SerializeField] GameObject character2;

	GameObject chosenCharacter;

	public override void OnServerAddPlayer(NetworkConnection conn, short playerControllerId)
	{

		var player = (GameObject)GameObject.Instantiate(chosenCharacter, playerSpawnPos, Quaternion.identity);
		NetworkServer.AddPlayerForConnection(conn, player, playerControllerId);
	}

	public void FirstButton()
	{
		chosenCharacter = character1;
	}

	public void SecondButton()
	{
		chosenCharacter = character2;
	}
}