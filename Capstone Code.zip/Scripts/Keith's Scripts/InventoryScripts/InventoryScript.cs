﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InventoryScript : MonoBehaviour
{

	public bool[] isFull;
	public GameObject[] slots;

	public void Start()
	{
		//slots = GameObject.FindGameObjectsWithTag("Slots");
	}
}
