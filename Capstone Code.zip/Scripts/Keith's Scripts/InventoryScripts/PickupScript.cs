﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickupScript : MonoBehaviour
{

	public InventoryScript inventory;
	public GameObject itemButton;


    void Start()
    {
		//UN COMMENT WHEN READY
		inventory = GameObject.FindGameObjectWithTag("Player").GetComponent<InventoryScript>();   
    }

	private void OnTriggerStay(Collider other)
	{
		
		if (other.CompareTag("Player") && Input.GetKeyDown(KeyCode.Space))
		{
            Pickup();
            GetComponent<BoxCollider>().enabled = false;

        }
		if(Input.GetKeyUp(KeyCode.Space))
		{
			GetComponent<BoxCollider>().enabled = true;
		}
	}

    public void Pickup()
    {
        
        for (int i = 0; i < inventory.slots.Length; i++)
        {
           
            if (inventory.isFull[i] == false)
            {
                
                //ITEM CAN BE PICKED UP AND ADDED TO INVENTORY
                inventory.isFull[i] = true;
                Instantiate(itemButton, inventory.slots[i].transform, false);
                Destroy(gameObject);
                break;
               
            }
        }
    }

	public void Update()
	{
		inventory = GameObject.FindGameObjectWithTag("Player").GetComponent<InventoryScript>();
	}

}
