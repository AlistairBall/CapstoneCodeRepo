﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class AvatarSetup : MonoBehaviour
{
	private PhotonView PV;
	//public GameObject myCharacter;
	public GameObject myAvatar;
	public int characterValue;
	public int spawnPicker = 1;
    // Start is called before the first frame update
    void Start()
    {
		PV = GetComponent<PhotonView>();
		if(PV.IsMine)
		{
			//PV.RPC("RPC_AddCharacter", RpcTarget., PlayerInfo.PI.mySelectedCharacter);
			AddCharacter(PlayerInfo.PI.mySelectedCharacter);
		}
    }


	[PunRPC]
	void RPC_AddCharacter(int whichCharacter)
	{
		
		if (whichCharacter == 1)
		{
			spawnPicker = 0;
			myAvatar = PhotonNetwork.Instantiate(Path.Combine("PhotonPrefabs", "Player1Avatar"),
				GameSetup.GS.spawnPoints[spawnPicker].position, GameSetup.GS.spawnPoints[spawnPicker].rotation, 0);
		}

		else
		{
			spawnPicker = 1;
			myAvatar = PhotonNetwork.Instantiate(Path.Combine("PhotonPrefabs", "Player2Avatar"),
				GameSetup.GS.spawnPoints[spawnPicker].position, GameSetup.GS.spawnPoints[spawnPicker].rotation, 0);
		}
	}

	
	void AddCharacter(int whichCharacter)
	{
		
		if (whichCharacter == 0)
		{
			spawnPicker = 0;
			myAvatar = PhotonNetwork.Instantiate(Path.Combine("PhotonPrefabs", "Player1Avatar"),
				GameSetup.GS.spawnPoints[spawnPicker].position, GameSetup.GS.spawnPoints[spawnPicker].rotation, 0);
		}

		else
		{
			spawnPicker = 1;
			myAvatar = PhotonNetwork.Instantiate(Path.Combine("PhotonPrefabs", "Player2Avatar"),
				GameSetup.GS.spawnPoints[spawnPicker].position, GameSetup.GS.spawnPoints[spawnPicker].rotation, 0);
		}
	}
}
