﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PossesionScript : MonoBehaviour
{
	// Start is called before the first frame update
	public GameObject[] characters;
	public GameObject currentCharacter;
	public int charactersIndex;

	void Start()
	{
		charactersIndex = 0;
		currentCharacter = characters[0];
	}

	// Update is called once per frame
	void Update()
	{
		if(Input.GetKeyDown(KeyCode.P))
		{
			currentCharacter.GetComponent<TempMovement>().enabled = false;
			//currentCharacter.GetComponentInChildren<Camera>().enabled = false;
			charactersIndex++;
			if (charactersIndex == characters.Length)
			{
				charactersIndex = 0;
			}
			//characters[charactersIndex].GetComponentInChildren<Camera>().enabled = true;
			characters[charactersIndex].GetComponent<TempMovement>().enabled = true;
			currentCharacter = characters[charactersIndex];

		}
	}
}
