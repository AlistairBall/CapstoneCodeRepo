﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;


public class PlayerSetup : MonoBehaviour

{
	//THIS IS FOR NETWORKING SO THAT ONE PLAYER WONT HAVE CONTROL OF 2 CHARACTERS
	private PhotonView PV;
	[SerializeField] // -> allows us to access this in the inspector
	Behaviour[] componentsToDisable;

	Camera sceneCamera;

	void Start()
	{
		PV = GetComponent<PhotonView>();
		if (!PV.IsMine)
		{
			for (int i = 0; i < componentsToDisable.Length; i++)
			{
				//loop through all the components and disable them since we arent using them.
				componentsToDisable[i].enabled = false;
			}
		}
	}

}
