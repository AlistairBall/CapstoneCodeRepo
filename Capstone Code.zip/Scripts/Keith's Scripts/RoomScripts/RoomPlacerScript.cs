﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;


public class RoomPlacerScript : MonoBehaviourPun
{

	 private PhotonView PV;

	//check to see if the right camera is active
	public GameObject MapCamera;

	//Need to make a public GameObject of each room we intend on using right here and then add it to the gameobject.
	public GameObject shopRoomPrefab;
	public GameObject basicRoomPrefab;
	public GameObject combatRoomPrefab;
	public GameObject trapRoom01Prefab;
	public GameObject trapRoom02Prefab;
	public GameObject combatRoom02Prefab;

	////testing


	

	RaycastHit hitInfo;
	private Gridscript grid;

	public int RoomType = 0;

	private void Awake()
	{
		grid = FindObjectOfType<Gridscript>();
		PV = GetComponent<PhotonView>();
		
		
	}

	// Update is called once per frame
	public void Update()
	{
		if (MapCamera == null)
		{
			MapCamera = GameObject.FindGameObjectWithTag("MainCamera");
		}
		
		if (Input.GetMouseButtonDown(0) && MapCamera.activeSelf == true)
		{
			
			//does a ray to figure out where you clicked
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			

			if (Physics.Raycast(ray, out hitInfo))
			{
				BoxCollider bc = hitInfo.collider as BoxCollider;

				if (bc != null)
				{
					PV.RPC("RPC_PlaceRoomNear", RpcTarget.All, hitInfo.point, RoomType);
					bc.gameObject.SetActive(false);
				}
								     
			}
		}

	


		  
    }

 
	[PunRPC]
	void RPC_PlaceRoomNear(Vector3 clickPoint, int RoomType)
	{
		var finalPosition = grid.GetNearestPointOnGrid(clickPoint);
		Quaternion spawnRotation = Quaternion.Euler(0.0f, 0.0f, 0.0f);

		if (RoomType == 1)
		{
			//TRAP ROOM 2
			GameObject room = (GameObject)PhotonNetwork.InstantiateSceneObject("Room_Trap02", finalPosition, Quaternion.identity);
			
		}

		else if (RoomType == 2)
		{
			//SHOP ROOM
			GameObject room = (GameObject)PhotonNetwork.InstantiateSceneObject("shopRoomPrefab", finalPosition, Quaternion.identity);
			
		}

		else if(RoomType == 3)
		{
			//BASIC ROOM
			GameObject room = (GameObject)PhotonNetwork.InstantiateSceneObject("Room_Base", finalPosition, Quaternion.identity);
		}

		else if (RoomType == 4)
		{
			//COMBAT ROOM
			GameObject room = (GameObject)PhotonNetwork.InstantiateSceneObject("combatRoomPrefab", finalPosition, Quaternion.identity);
		}

		else if (RoomType == 5)
		{
			//TRAP ROOM 1
			GameObject room = (GameObject)PhotonNetwork.InstantiateSceneObject("Room_Trap01", finalPosition, Quaternion.identity);
		}

		else if (RoomType == 6)
		{
			//COMBAT ROOM 2
			GameObject room = (GameObject)PhotonNetwork.InstantiateSceneObject("Room_Combat03", finalPosition, Quaternion.identity);
		}
	}


	//Switch the types of rooms that will spawn in on click, made it public so that the RoomPlacer script can access these.

	public void ShopRoom()
	{
		RoomType = 2;
		Debug.Log("Shop room selected");
	}

	public void BasicRoom()

	{
		RoomType = 3;
		Debug.Log("Basic room selected");
	}

	public void CombatRoom()

	{
		RoomType = 4;
		Debug.Log("Combat room selected");
	}

	public void CombatRoom2()
	{
		RoomType = 6;
		Debug.Log("Combat room 2 selected");
	}

	public void Trap01Room()

	{
		RoomType = 5;
		Debug.Log("Trap 01 room selected");
	}

	public void Trap02Room()
	{

		RoomType = 1;
		Debug.Log("Trap 02 room selected");
	}



	//OLD UNET STUFF, KEEPING FOR REFERENCE
	//   [Command]
	//void CmdPlaceRoomNear(Vector3 clickPoint, int RoomType)
	//{
	//       var finalPosition = grid.GetNearestPointOnGrid(clickPoint);
	//       Quaternion spawnRotation = Quaternion.Euler(0.0f, 0.0f, 0.0f);

	//       if (RoomType == 1)
	//       {
	//		Debug.Log("Server spawning in DM room");
	//           GameObject room = (GameObject)Instantiate(prefabRoomOne, finalPosition, Quaternion.identity);
	//           NetworkServer.Spawn(room);
	//       }

	//       else if (RoomType == 2)
	//       {

	//           GameObject room = (GameObject)Instantiate(prefabRoomTwo, finalPosition, Quaternion.identity);
	//           NetworkServer.Spawn(room);
	//       }


	//   }

	// [ClientRpc]
	// void RpcPlaceRoomNear(Vector3 clickPoint, int RoomType)
	// {
	//     if (RoomType == 1)
	//     {
	//Debug.Log("Client spawning in DM room");
	//         GameObject room = (GameObject)Instantiate(prefabRoomOne, clickPoint, Quaternion.identity);
	//         NetworkServer.SpawnWithClientAuthority(room, gameObject);
	//     }

	//     else if (RoomType == 2)
	//     {
	//         GameObject room = (GameObject)Instantiate(prefabRoomTwo, clickPoint, Quaternion.identity);
	//         NetworkServer.SpawnWithClientAuthority(room, gameObject);
	//     }


	// }





}
