﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MageEnemySpawner : MonoBehaviour
{

	public GameObject[] Spawner;
	public GameObject MageEnemy;


	private PhotonView PV;
	private bool spawn = false;


	// Start is called before the first frame update
	void Start()
	{
		PV = GetComponent<PhotonView>();
	}

	// Update is called once per frame
	void Update()
	{
		Spawner = GameObject.FindGameObjectsWithTag("MageSpawn");
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "EnemySpawnTrigger")
		{

			Debug.Log("PLAYER ENTERED ROOM");
			spawn = true;
			print(spawn);
			// Door.SetActive(true);
			PV.RPC("RPC_Spawn", RpcTarget.All);


		}
	}

	[PunRPC]
	void RPC_Spawn()
	{
		if (spawn)
		{
			for (int i = 0; i < Spawner.Length; i++)
			{
			
				if (Spawner[i].gameObject.tag == "MageSpawn")
				{
					PhotonNetwork.Instantiate("MageEnemy", Spawner[i].transform.position, Quaternion.identity);
				}
			}

		}
	}


}