﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MagicEnemy : MonoBehaviour
{
    public Transform Enemy;
    public Transform SpawnSpell;
    public Transform PlayerPos;

    public GameObject player;
    public GameObject Spawner;
    public GameObject DamageText;
    public GameObject Staff;
    public GameObject PoisonSpell;
    Animator Anim;

    int rotationSpeed = 80;
    private int health;
    private float speed;
    private float SpellRate = 5.0f;
    private float time;
    private bool HitOnce = false;
    private bool once = false;
    private bool attack = false;
    
    void Start()
    {
        Enemy = transform;
        player = GameObject.FindGameObjectWithTag("Player");
        PlayerPos = player.transform;
        Staff = GameObject.FindGameObjectWithTag("MyStaff");
        Anim = GetComponent<Animator>();
        InvokeRepeating("ResetDamage", 1.0f, 1.2f);
        health = GetComponent<EnemyHealth>().health;
    }

    // Update is called once per frame
    void Update()
    {
        //set EnemuHealth reference to local health
        GetComponent<EnemyHealth>().health = health;

        //enemies face player and do not rotate on the x axis
        Vector3 direction = PlayerPos.position - this.transform.position;
        float angle = Vector3.Angle(direction, Enemy.up);

        //If not attacking, chase player
        if (!attack)
        {
            speed = 0.06f;
            this.transform.Translate(0, 0, Time.deltaTime * speed);
            this.transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), rotationSpeed * Time.deltaTime);
            transform.position = Vector3.MoveTowards(transform.position, player.transform.position, 0.07f);
            Anim.SetInteger("Conditions", 1);

        }

        //If in range, stop moving and begin attacking
        if (attack)
        {
            //idle until attack animation
            speed = 0.0f;
            Anim.SetInteger("Conditions", 3);

            //attack rate
            if (time > SpellRate)
            {
                Anim.SetInteger("Conditions", 2);
                Invoke("RangedSpell", 1.0f);
                time = 0;
            }
        }
        time += Time.deltaTime;

        //death logic
        if (health <= 0)
        {
            //once is used so that this logic is not called every frame
            if (!once)
            {
                once = true;
                Anim.SetBool("Damaged", false);
                Anim.SetInteger("Condition", 9);
                Destroy(gameObject, 2.2f);
                speed = 0.0f;
                //drop spawner after death animation plays out
                Invoke("DropSpawner", 2.19f);
            }
        }
        LookAtTarget();
    }

    void LookAtTarget()
    {
        //always face direction of player
        Vector3 dir = PlayerPos.position - transform.position;
        Quaternion lookRotation = Quaternion.LookRotation(dir);
        Vector3 rotation = Quaternion.Lerp(transform.rotation, lookRotation, Time.deltaTime * rotationSpeed).eulerAngles;
        transform.rotation = Quaternion.Euler(0f, rotation.y, 0f);
    }

    void OnCollisionEnter(Collision other)
    {
        GameObject instance;
        if (health > 0)
        {
            if (other.gameObject.tag == "Equipped" && HitOnce == false)
            {
                HitOnce = true;
                //get weapon damage from weapon
                int Damage = other.gameObject.GetComponent<WeaponDamage>().damage;
                health -= Damage;
                //Anim.SetBool("Damaged", true);

                 //Damage text
                instance = Instantiate(DamageText, transform.position, Quaternion.identity);
                instance.transform.GetComponent<CombatText>().mainTarget = gameObject;
                instance.transform.GetComponent<CombatText>().damage = Damage;
            }
             
                 //Damage from player spells
            if (other.gameObject.tag == "Spell")
            {              
                int Damage = other.gameObject.GetComponent<WeaponDamage>().damage;
                health -= Damage;

                //Damage text
                instance = Instantiate(DamageText, transform.position, Quaternion.identity);
                instance.transform.GetComponent<CombatText>().mainTarget = gameObject;
                instance.transform.GetComponent<CombatText>().damage = Damage;
                Destroy(other.gameObject);
            }
        }
    }

    //instantiate spawner on death
    void DropSpawner()
    {
        Instantiate(Spawner, transform.position, Quaternion.identity);
        Spawner.SetActive(true);
    }

    void OnTriggerEnter(Collider other)
    {
        //If player is within range, begin attack state
        if (other.gameObject.tag == "Player")
        {
            attack = true;
        }
    }
    void OnTriggerExit(Collider other)
    {
        //If player is out of range exit attack state
        if (other.gameObject.tag == "Player")
        {
            attack = false;
        }
    }

    //instantiate spell prefab
    void RangedSpell()
    { 
        SpawnSpell = Staff.transform.GetChild(0);
        Instantiate(PoisonSpell, SpawnSpell.transform.position, Quaternion.identity);
    }

    void ResetDamage()
    {
        HitOnce = false;
    }

}
