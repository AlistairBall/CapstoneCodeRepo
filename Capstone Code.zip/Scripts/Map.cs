﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map : MonoBehaviour
{

    public List<GameObject> roomList;//list of room types
    public GameObject hallway;
    GameObject[,] goMap;//2d array of room gameobjects
    public Room[,] roomMap;

    float roomSpacing = 30f;//space between each room's origin on the grid
    int mapSize = 6; // determines the l and w of the map in rooms ie 10x10 rooms

    // Use this for initialization
    void Start ()
    {
        goMap = new GameObject[mapSize,mapSize];

        for (int i = 0; i < mapSize; i++)
        {
            for(int j = 0; j < mapSize; j++)
            {
                goMap[i, j] = roomList[0];

                if (goMap[i, j] != null)
                {
                    GameObject tmpRoom = Instantiate(goMap[i,j], this.transform);//spawn the room stored in the map
                    tmpRoom.transform.position = new Vector3(i * roomSpacing,0, j * roomSpacing);// offset the rooms position so it fits correctly on the map

                    GameObject tmpHallway = Instantiate(hallway, tmpRoom.transform);
                    hallway.transform.position = new Vector3(i * roomSpacing/4, 0, j * roomSpacing/4);
                }
            }
        }
	}
	
	// Update is called once per frame
	void Update ()
    {
        /*for (int i = 0; i < map.Length; i++)
        {
            for (int j = 0; j < map.Length; j++)
            {
                if(map[i,j] != null)
                {
                    GameObject tmpRoom = Instantiate(roomList[0], this.transform);
                    tmpRoom.transform.position = new Vector3(i * roomSpacing, j * roomSpacing);
                }
            }
        }*/
    }
}
