﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player2 : MonoBehaviour
{
    //Networking Stuff
    private PhotonView PV;

    // Start is called before the first frame update
    private float speed = 6.0f;
    private bool isDead = false;
    private Vector3 moveDirection;
    public Transform cameraComponent;
	public GameObject necroEndGameButton;
	public GameObject necroEndGameText;

    Animator Anim;
    void Start()
    {
        PV = GetComponent<PhotonView>();
        Anim = GetComponent<Animator>();
		PhotonNetwork.SetMasterClient(PhotonNetwork.PlayerList[1]);

	}

    // Update is called once per frame
    void Update()
    {

        if (PV.IsMine)
        {
            if (isDead == false)
            {
                //update what forward is
                Vector3 cameraComponentF = cameraComponent.forward;
                Vector3 cameraComponentR = cameraComponent.right;

                cameraComponentF.y = 0;
                cameraComponentR.y = 0;
                cameraComponentF = cameraComponentF.normalized;
                cameraComponentR = cameraComponentR.normalized;

                //Movement script
                if (Input.GetKey(KeyCode.W))
                {
                    Anim.SetInteger("Condition", 1);
                    transform.position += (cameraComponentF * Input.GetAxis("Vertical") * speed) * Time.deltaTime;

                }
                if (Input.GetKey(KeyCode.S))
                {
                    Anim.SetInteger("Condition", 3);
                    transform.position += (cameraComponentF * Input.GetAxis("Vertical") * speed) * Time.deltaTime;
                }
                //Move Left or Right
                if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D))
                {
                    transform.position += (cameraComponentR * Input.GetAxis("Horizontal") * speed) * Time.deltaTime;
                    Anim.SetInteger("Condition", 6);
                }

                //if In any other animation state do not idle
                if (Anim.GetInteger("Condition") > 0)
                {
                    Anim.SetBool("Idle", false);

                }

                //return to idle if no key is pressed.
                if (!Input.anyKey)
                {
                    Anim.SetBool("Idle", true);
                    Anim.SetInteger("Condition", 0);
                }
            }
        }


		if (isDead == true)
		{
			Debug.Log("IN PLAYER 2 DEATH FUNCTION");
			necroEndGameButton.SetActive(true);
			necroEndGameText.SetActive(true);
			Anim.SetInteger("Condition", 10);
			
		}

	}

	//public void OnTriggerEnter(Collision other)
	//{
	//	if (other.gameObject.tag == "Equipped" || other.gameObject.tag == "Spell")
	//	{
	//		Debug.Log("Colliding with other player");
	//		isDead = true;
	//	}
	//}

	public void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "Equipped" || other.gameObject.tag == "Spell")
		{
			Debug.Log("Colliding with other player");
			isDead = true;
		}
	}



}
