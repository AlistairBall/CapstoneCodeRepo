﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    // This is an alternate movement script for when the enemy is being posessed, it begins disabled

    private Vector3 moveDirection;
    public Transform cameraComponent;

    public GameObject camera;
    public GameObject Spawner;
    public GameObject orb;
    public GameObject weapon;
    Animator Anim;

    private bool once = false;
    private float speed = 6.0f;

    void Start()
    {
        Anim = GetComponent<Animator>();
        camera.SetActive(true);
        orb = GameObject.Find("ScryingOrb");
        orb.GetComponent<ScryingOrb>().Posessing = true;
        weapon.GetComponent<BoxCollider>().enabled = true;
    }

    // Update is called once per frame
    void Update()
    {

       //updates forward direction
            Vector3 cameraComponentF = cameraComponent.forward;
            Vector3 cameraComponentR = cameraComponent.right;

            cameraComponentF.y = 0;
            cameraComponentR.y = 0;
            cameraComponentF = cameraComponentF.normalized;
            cameraComponentR = cameraComponentR.normalized;

         //movement
            if (Input.GetKey(KeyCode.W))
            {
                Anim.SetInteger("Condition", 1);
                transform.position += (cameraComponentF * Input.GetAxis("Vertical") * speed) * Time.deltaTime;

            }
            if (Input.GetKey(KeyCode.S))
            {
                Anim.SetInteger("Condition", 3);
                transform.position += (cameraComponentF * Input.GetAxis("Vertical") * speed) * Time.deltaTime;
            }
            //Move Left or Right
            if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D))
            {
                transform.position += (cameraComponentR * Input.GetAxis("Horizontal") * speed) * Time.deltaTime;
                Anim.SetInteger("Condition", 6);
            }

       if(GetComponent<EnemyHealth>().health <= 0)
        {
            if (!once)
            {
                once = true;
                Anim.SetInteger("Condition", 10);
                Destroy(gameObject, 2.2f);
                //drop spawner after death animation plays out
                Invoke("DropSpawner", 2.19f);
            }
        }

       //play attack animation
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            Anim.SetInteger("Condition", 2);
        }


            //if In any other animation state do not idle
            if (Anim.GetInteger("Condition") > 0)
            {
                Anim.SetBool("Idle", false);

            }

            //return to idle if no key is pressed.
            if (!Input.anyKey && once == false)
            {
                Anim.SetBool("Idle", true);

                Anim.SetInteger("Condition", 0);
            }

    }

    void DropSpawner()
    {
        Instantiate(Spawner, transform.position, Quaternion.identity);
        Spawner.SetActive(true);
        orb.GetComponent<ScryingOrb>().Posessing = false;
    }



}
