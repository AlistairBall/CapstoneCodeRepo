﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PosessEnemy : MonoBehaviour
{
    // Start is called before the first frame update
    GameObject selectedEnemy;
    GameObject enemyCamera;
 
    public RuntimeAnimatorController EnemyAnim;
    public RuntimeAnimatorController MageAnim;

    // Update is called once per frame
    void Update()
    {
        selectedEnemy = GetComponent<SelectEnemy>().SelectedEnemy;
        
        if (selectedEnemy != null)
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                //checks what enemy is being posessed and enables/disables the appropriate scripts
                if(selectedEnemy.GetComponent<EliteEnemy>() != null)
                {
                    selectedEnemy.GetComponent<Animator>().runtimeAnimatorController = EnemyAnim;
                    selectedEnemy.GetComponent<EliteEnemy>().enabled = false;
                    selectedEnemy.GetComponent<EnemyMovement>().enabled = true;
                }
               
                if(selectedEnemy.GetComponent<BasicEnemy>() != null)
                {
                    selectedEnemy.GetComponent<Animator>().runtimeAnimatorController = EnemyAnim;
                    selectedEnemy.GetComponent<BasicEnemy>().enabled = false;
                    selectedEnemy.GetComponent<EnemyMovement>().enabled = true;
                }

                if (selectedEnemy.GetComponent<MagicEnemy>() != null)
                {
                    selectedEnemy.GetComponent<Animator>().runtimeAnimatorController = MageAnim;
                    selectedEnemy.GetComponent<MagicEnemy>().enabled = false;
                    selectedEnemy.GetComponent<MageMovement>().enabled = true;
                }
            }
        } 
    }
}
