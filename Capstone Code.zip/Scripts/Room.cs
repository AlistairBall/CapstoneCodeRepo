﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Room : MonoBehaviour
{
    public bool[] doors = new bool[4]; // whether or not there is a door at 0(north), 1(east) 2(south) 3(west)
                                       //affect this in unity editor for each room

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void onPlace() // when the room is placed into the dungeon
    {
        //door 0 must be linked with a 2
        //door 1 must be linked with a 3
        //door 2 must be linked with a 0
        //door 3 must be linked with a 1
    }
}
