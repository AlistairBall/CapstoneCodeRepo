﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElectricTrap : MonoBehaviour
{
    public GameObject Player;
    public ParticleSystem[] particleEffect;
    public GameObject DamageText;
    public LayerMask m_LayerMask;

    private bool TrapActive = false;
    private float tickTime;
   
    // Start is called before the first frame update
    void Start()
    {
        Player = GameObject.FindGameObjectWithTag("Player");
        InvokeRepeating("Switch", 4.0f, 4.0f);
       
    }

    // Update is called once per frame
    void Update()
    {
        Damage();
     
        //player particles based on boolean
        if (TrapActive)
        {
            for (int i = 0; i < particleEffect.Length; i++)
            {
                particleEffect[i].Play();
            }
        }

        else
        {
            for (int i = 0; i < particleEffect.Length; i++)
            {
                particleEffect[i].Stop();
            }
        }
    }

    void OnTriggerStay(Collider other)
    {
        //Deal damage to player
        if (TrapActive)
        {
            if (other.gameObject.tag == "Player")
            {
                tickTime -= Time.deltaTime;
                if (tickTime <= 0)
                {
                    Player.GetComponent<PlayerHealth>().Health -= 10;
                    tickTime = 1.0f;
                }
            }
        }
        
    }

  //switch boolean to trigger particle emitter to play or stop
    void Switch()
    {
        TrapActive = !TrapActive;
    }

    void Damage()
    {
        //checks what enemy is in damage zone at any given time and applies damage
        GameObject instance;
        Collider[] Enemies = Physics.OverlapBox(transform.position, transform.localScale * 5, Quaternion.identity, m_LayerMask);
        int i = 0;
      
        while (i < Enemies.Length)
        {
            tickTime -= Time.deltaTime;
            if (TrapActive)
            {
                if (tickTime <= 0)
                {
                    foreach (Collider hit in Enemies)
                    {
                        //Enemy take damaage
                        Enemies[i].GetComponent<EnemyHealth>().health -= 10;

                        if (DamageText != null)
                        {
                            instance = Instantiate(DamageText, transform.position, Quaternion.identity);
                            instance.transform.GetComponent<CombatText>().mainTarget = Enemies[i].gameObject;
                            instance.transform.GetComponent<CombatText>().damage = 10;
                        }
                    }
                    tickTime = 2.0f;
                }
            }
           i++;
        }
    }
}
