﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireAcidTrap : MonoBehaviour
{
    public ParticleSystem particleEffect;

    // Start is called before the first frame update
    void Start()
    {
        particleEffect.Stop();
    }

    //player particle emitter based on triggers for player or enemy
    void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Player" || other.gameObject.tag == "Enemy")
        {
            particleEffect.Play();
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "Player" || other.gameObject.tag == "Enemy")
        {
            particleEffect.Stop();
        }
    }
}
