﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoisonDamage : MonoBehaviour
{
   
    public GameObject Player;
    public GameObject Enemy;
    public GameObject DamageText;
    public LayerMask m_LayerMask;

    public float tickTime;
    // Start is called before the first frame update
    void Start()
    {
        Player = GameObject.FindGameObjectWithTag("Player");
    }

    // Update is called once per frame
    void Update()
    {
        Damage();
    }

    void OnTriggerStay(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            tickTime -= Time.deltaTime;
            if (tickTime <= 0)
            {
                Player.GetComponent<PlayerHealth>().Health -= 3;
                tickTime = 1.0f;
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        StartCoroutine("Poison");

    }

    void Damage()
    {
        //checks if enemy is in damage zone at any given time
        GameObject instance;
        Collider[] Enemies = Physics.OverlapBox(transform.position, new Vector3(transform.localScale.x * 4, transform.localScale.y * 2, transform.localScale.z * 20), Quaternion.identity, m_LayerMask);
        int i = 0;
  
        while (i < Enemies.Length)
        {
            tickTime -= Time.deltaTime;

            if (tickTime <= 0)
            {
                foreach (Collider hit in Enemies)
                {

                    //Enemy take damaage
                    Enemies[i].GetComponent<EnemyHealth>().health -= 3;

                    instance = Instantiate(DamageText, transform.position, Quaternion.identity);
                    instance.transform.GetComponent<CombatText>().mainTarget = Enemies[i].gameObject;
                    instance.transform.GetComponent<CombatText>().damage = 3;
                }
                tickTime = 0.5f;
            }
          i++;
        }
    }

    IEnumerator Poison()
    {
        for (int i = 0; i < 3; i++)
        {

            Player.GetComponent<PlayerHealth>().Health -= 1;
            yield return new WaitForSeconds(2);
            i++;

        }
    }

  


}
