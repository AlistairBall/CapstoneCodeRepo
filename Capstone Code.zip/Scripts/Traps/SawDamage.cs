﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SawDamage : MonoBehaviour
{
    public GameObject player;
    public GameObject DamageText;
    public LayerMask m_LayerMask;
    public Animator anim;

    private bool HitOnce = false;
   
    // Start is called before the first frame update
    void Start()
    { 
        player = GameObject.FindGameObjectWithTag("Player");
        anim = GetComponent<Animator>();
        anim.Play("SwingingAxe", -1, Random.Range(0.0f, 1.0f));
        anim.Play("SawMotion", -1, Random.Range(0.0f, 2.0f));
        InvokeRepeating("ResetDamage", 1.0f, 1.5f);
    }

    // Update is called once per frame
    void Update()
    {
        Damage();
    }

    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "Player" && HitOnce == false)
        {
            player.GetComponent<PlayerHealth>().Health -= 10;
            HitOnce = true;
        }  
    }

    void ResetDamage()
    {
        HitOnce = false;
    }

    void Damage()
    {
        //checks what enemies are in damage zone at any time
        GameObject instance;
        Collider[] Enemies = Physics.OverlapBox(transform.position, transform.localScale, Quaternion.identity, m_LayerMask);
        int i = 0;
     
        while (i < Enemies.Length)
        {
            foreach (Collider hit in Enemies)
            {
                if (HitOnce == false)
                {
                    //Enemy take damaage
                    Enemies[i].GetComponent<EnemyHealth>().health -= 20;

                    instance = Instantiate(DamageText, transform.position, Quaternion.identity);
                    instance.transform.GetComponent<CombatText>().mainTarget = Enemies[i].gameObject;
                    instance.transform.GetComponent<CombatText>().damage = 20;
                    HitOnce = true;
                }
            }
          i++;
        }
    }
}
