﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpikeWall : MonoBehaviour
{
    public GameObject player;
    public GameObject DamageText;
    public Animator Anim;
    public LayerMask m_LayerMask;

    private bool push = false;
    private bool HitOnce = false;
    
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        Anim = GetComponent<Animator>();
        Anim.SetBool("Push", false);
        InvokeRepeating("ResetDamage", 1.0f, 1.5f);
    }

    // Update is called once per frame
    void Update()
    {
        Damage();
    }

    void OnCollisionEnter(Collision other)
    {
        //ensures that the player will only take damage in on instance of the collision
        if (other.gameObject.tag == "Player" && HitOnce == false)
        {
            player.GetComponent<PlayerHealth>().Health -= 10;
            HitOnce = true;
        }  
    }

    //play animations if player or enemy enter/leave
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player" || other.gameObject.tag == "Enemy")
        {
            Anim.SetBool("Push", true);
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "Player" || other.gameObject.tag == "Enemy")
        {
            Anim.SetBool("Push", false);
        }
    }


    void ResetDamage()
    {
        HitOnce = false;
    }

    void Damage()
    {
        //use physics overlap to see what enemies are in the damage zone at any given time.
        GameObject instance;
        Collider[] Enemies = Physics.OverlapBox(transform.position, transform.localScale * 3, Quaternion.identity, m_LayerMask);
        int i = 0;
        if (Enemies.Length > Enemies.Length)
        {

        }
        while (i < Enemies.Length)
        {
            foreach (Collider hit in Enemies)
            {
                if (HitOnce == false)
                {
                    //Enemy take damaage
                    Enemies[i].GetComponent<EnemyHealth>().health -= 20;

                    instance = Instantiate(DamageText, transform.position, Quaternion.identity);
                    instance.transform.GetComponent<CombatText>().mainTarget = Enemies[i].gameObject;
                    instance.transform.GetComponent<CombatText>().damage = 20;
                    HitOnce = true;
                }
            }
            i++;
        }
    }
}
