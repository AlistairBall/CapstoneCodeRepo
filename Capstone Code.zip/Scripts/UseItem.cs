﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UseItem : MonoBehaviour
{
    Animator Anim;
    public GameObject LightningSpell;
    public GameObject FireSpell;
    public GameObject LightningAim;
    public GameObject FireAim;
    public GameObject currentItem;
    public GameObject player;
    public GameObject candle;
    public GameObject LightningScroll;
    public GameObject FireScroll;
    public GameObject LargeHealth;

    public Text tips;
    public InventoryScript inventory;
    public GameObject itemButton;

    // Start is called before the first frame update
    void Start()
    {
        Anim = GetComponent<Animator>();
        LightningAim.SetActive(false);
        FireAim.SetActive(false);
        currentItem = GameObject.FindGameObjectWithTag("Candle");
        player = GameObject.FindGameObjectWithTag("Player");
        candle = GameObject.FindGameObjectWithTag("Candle");

        inventory = GetComponent<InventoryScript>();
    }

    // Update is called once per frame
    void Update()
    {
        //when not using item revert to default candle
        if (currentItem == null)
        {
            tips.GetComponent<FadeText>().fading = false;
            candle.SetActive(true);
        }

        //When E is pressed and item is held
        if (Input.GetKeyDown(KeyCode.E) && currentItem != null)
        {
            tips.GetComponent<FadeText>().fading = false;

                //Sets aimer for scroll spell effects
                if (currentItem.gameObject.tag == "LightningScroll")
                {
                    LightningAim.SetActive(true);
                }
                else if (currentItem.gameObject.tag == "FireScroll")
                {
                    FireAim.SetActive(true);
                }

                //uses large health potion
                else if (currentItem.gameObject.tag == "LargePotion")
                {
                    player.GetComponent<PlayerHealth>().Health += 50;
                    Anim.SetInteger("Condition", 11);
                    Destroy(currentItem, 1);
                }

                //uses small health potion
                else if (currentItem.gameObject.tag == "SmallPotion")
                {
                    player.GetComponent<PlayerHealth>().Health += 25;
                    Anim.SetInteger("Condition", 11);
                    Destroy(currentItem, 1);
                
                }
        }

        //When E is released
        else if (Input.GetKeyUp(KeyCode.E))
        {
            if (currentItem != null)
            {
                //Cast Scroll spells
                if (currentItem.gameObject.tag == "LightningScroll")
                {
                    Anim.SetInteger("Condition", 11);
                    castSpell();
                    LightningAim.SetActive(false);
                    candle.SetActive(true);

                }
                else if (currentItem.gameObject.tag == "FireScroll")
                {
                    Anim.SetInteger("Condition", 11);
                    castSpell();
                    FireAim.SetActive(false);
                    candle.SetActive(true);
                }
            }
        }

        //If Q is down
        if (Input.GetKeyDown(KeyCode.Q))
        {
            if (currentItem != null)
            {
                tips.GetComponent<FadeText>().fading = false;

                //Return lightening scroll back into inventory
                if (currentItem.gameObject.tag == "LightningScroll")
                {
                    candle.SetActive(true);
                    Destroy(currentItem);
                    itemButton = LightningScroll.GetComponent<PickupScript>().itemButton;

                    for (int i = 0; i < inventory.slots.Length; i++)
                    {

                        if (inventory.isFull[i] == false)
                        { 
                            inventory.isFull[i] = true;
                            Instantiate(itemButton, inventory.slots[i].transform, false);
                            break;
                        }
                    }
                }
                //Return fire scroll back into inventory
                else if (currentItem.gameObject.tag == "FireScroll")
                {
                    candle.SetActive(true);
                    Destroy(currentItem);
                    itemButton = FireScroll.GetComponent<PickupScript>().itemButton;

                    for (int i = 0; i < inventory.slots.Length; i++)
                    {

                        if (inventory.isFull[i] == false)
                        {
                            inventory.isFull[i] = true;
                            Instantiate(itemButton, inventory.slots[i].transform, false);
                            break;
                        }
                    } 
                }
                //Return large health back into inventory
                else if (currentItem.gameObject.tag == "LargePotion")
                {

                    candle.SetActive(true);
                    Destroy(currentItem);
                    itemButton = LargeHealth.GetComponent<PickupScript>().itemButton;

                    for (int i = 0; i < inventory.slots.Length; i++)
                    {

                        if (inventory.isFull[i] == false)
                        {

                            //ITEM CAN BE PICKED UP AND ADDED TO INVENTORY
                            inventory.isFull[i] = true;
                            Instantiate(itemButton, inventory.slots[i].transform, false);

                            break;

                        }
                    }

                }
                //Return small health back into inventory
                else if (currentItem.gameObject.tag == "SmallPotion")
                {
                    candle.SetActive(true);
                    Destroy(currentItem);
                    itemButton = LargeHealth.GetComponent<PickupScript>().itemButton;

                    for (int i = 0; i < inventory.slots.Length; i++)
                    {
                        if (inventory.isFull[i] == false)
                        { 
                            inventory.isFull[i] = true;
                            Instantiate(itemButton, inventory.slots[i].transform, false);
                            break;
                        }
                    }
                }
            }
        }  
    }

    //instantiate spell prefab
    void castSpell()
    {
        GameObject instance;

        if (currentItem.gameObject.tag == "FireScroll")
        {
            instance = Instantiate(FireSpell, transform.position + (transform.forward * 5), transform.rotation);
            Destroy(currentItem);
        }
        else if (currentItem.gameObject.tag == "LightningScroll")
        {
            instance = Instantiate(LightningSpell, transform.position + (transform.forward * 5), transform.rotation);
            Destroy(currentItem);
        }


    }
}
